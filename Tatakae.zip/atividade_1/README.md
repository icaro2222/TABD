
:bank::control_knobs:

### **Modelo Entidade E Relacionamento** 
<table align="center">
	    <tr>
	        <td align="center">
	            <a href="https://github.com/icaro2222">
	                <img alt="Perfil do git do Ícaro" width="100" src="https://avatars.githubusercontent.com/u/71037296?v=4"></img>
	                <br/>
	                <b>Ícaro Dias</b>
	            </a>
	            <br><img src="https://cdn-icons-png.flaticon.com/128/3161/3161133.png" width="12%"/> Back End</br>
	        </td>
	    </tr>
</table>
